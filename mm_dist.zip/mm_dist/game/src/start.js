// Launch the game!
mm.game = new Phaser.Game(mm.width, mm.height, Phaser.CANVAS, 'Monster Multiplier', { preload: mm.preload, create: mm.create, update: mm.update, render: mm.render });


