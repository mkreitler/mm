mm.strings = {
	SPELLS: "Spells",
	TRAPS: "Traps",
	BEASTS: "Beasts",
}